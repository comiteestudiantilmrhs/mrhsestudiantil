/* M·LAB 3.0 — web del comité. Sin servidor: el progreso se guarda en el navegador de cada estudiante. */
const CONFIG = {
  // Formulario oficial de inscripción (Google Forms del comité)
  formUrl: 'https://forms.gle/gKAMfk2FQ1c8C2Ch9',
  // Correo institucional del comité
  email: 'comite_estudiantil_mrhs@monterrosaleshomeschool.edu.co',
  // OPCIONAL · Base de datos en Google Sheets (ranking + evidencias). Pega aquí la URL /exec de tu Apps Script.
  // Instrucciones: BASE_DE_DATOS_Google_Sheets.md. Si queda vacío, la web funciona igual (evidencias por correo).
  apiUrl: ''
};
const api = {
  on: () => !!CONFIG.apiUrl,
  async post(data) {
    await fetch(CONFIG.apiUrl, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(data) });
  },
  async get(action) {
    const r = await fetch(CONFIG.apiUrl + '?action=' + action); return r.json();
  }
};

const store = {
  get(k, d) { try { const v = localStorage.getItem('mlab_' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('mlab_' + k, JSON.stringify(v)); } catch (e) {} }
};
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = t => String(t ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = n => isFinite(n) ? '$' + Math.round(n).toLocaleString('es-CO') : '—';
function toast(t) { const e = $('#toast'); if (!e) return; e.textContent = t; e.classList.add('show'); setTimeout(() => e.classList.remove('show'), 2400); }

/* nav */
document.addEventListener('DOMContentLoaded', () => {
  // aparición suave al hacer scroll (todo queda visible si no hay soporte)
  if ('IntersectionObserver' in window && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.documentElement.classList.add('js');
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.remove('wait'); io.unobserve(e.target); } }), { rootMargin: '0px 0px -8% 0px' });
    $$('.section .card, .section .box, .section .stat, .section h2, .tool').forEach(el => { if (el.getBoundingClientRect().top > innerHeight) { el.classList.add('rv', 'wait'); io.observe(el); } });
  }
  const b = $('.burger'); if (b) b.onclick = () => $('.nav ul').classList.toggle('open');
  if ($('#retos-grid')) initRetos();
  if ($('#tools')) initTools();
  initJoin();
});

/* ---------------- RETOS ---------------- */
const BADGES = { radar: 'Radar', oido: 'Oído', chispa: 'Chispa', marca: 'Marca', v1: 'V1', prueba: 'Prueba', datos: 'Datos', cuentas: 'Cuentas', k10: '10K', eco: 'Eco', mercado: 'Mercado', pitch: 'Pitch' };
const RUTAS = { exp: 'Explorador', con: 'Constructor', lid: 'Líder', todos: 'Todas las rutas' };
const RETOS = [
 { id: 'safari', t: 'Safari de problemas', r: 'todos', b: 'radar', min: 60, xp: 30, img: 'p_descubre', d: 'Sal a cazar problemas reales en el colegio (sin fotos de personas).', s: ['Elige un espacio autorizado: cafetería, biblioteca, patio o salón.', 'Durante un día anota 5 situaciones que molesten o hagan perder tiempo.', 'Elige una y separa: síntoma, posibles causas y evidencia que necesitas.'], e: 'Foto de tu lista en la bitácora.', g: 'Cap. 2' },
 { id: 'molesta', t: 'Lo que me molesta en 60 segundos', r: 'exp', b: 'radar', min: 15, xp: 15, img: 'g_descubrir', d: 'Graba un audio o escribe: algo que te molesta y a quién más le pasa.', s: ['Piensa en algo que te moleste casi todos los días.', 'Cuéntalo en 60 segundos: qué pasa, cuándo y a quién más le pasa.', 'Dibuja cómo sería el mundo si eso estuviera resuelto.'], e: 'Dibujo o audio de 60 s.', g: 'Cap. 2' },
 { id: 'causa', t: 'Síntoma vs. causa', r: 'con', b: 'radar', min: 30, xp: 20, img: 'g_validar', d: 'Aprende a no confundir lo que ves con lo que lo provoca.', s: ['Toma un problema de tu safari.', 'Escribe el síntoma en una frase.', 'Pregunta “¿por qué?” cinco veces seguidas y anota cada respuesta.', 'Marca cuál causa podrían atacar ustedes.'], e: 'Cadena de 5 porqués.', g: 'Cap. 2' },
 { id: 'entrevistas', t: '5 entrevistas sin vender', r: 'con', b: 'oido', min: 90, xp: 40, img: 'g_personas', d: 'Habla con humanos de verdad y descubre lo que no sabías.', s: ['Escribe 5 preguntas abiertas sobre el pasado real (“cuéntame la última vez que…”).', 'Pide revisión a tu mentor.', 'Entrevista a 5 personas que no sean tus amigos cercanos. Usa códigos, no nombres.', 'Anota 3 patrones que se repitan.'], e: 'Notas con códigos y 3 patrones.', g: 'Cap. 3' },
 { id: 'usuario', t: 'Dibuja a tu usuario', r: 'exp', b: 'oido', min: 30, xp: 20, img: 'g_personas', d: '¿Para quién es tu idea? Dibújalo y escribe qué necesita.', s: ['Dibuja a la persona que tiene el problema.', 'Escribe a su alrededor: qué hace, qué le molesta y qué le gustaría.', 'Pregúntale a alguien real si se parece a ese dibujo.'], e: 'Dibujo con notas.', g: 'Cap. 3' },
 { id: 'diezideas', t: 'Diez ideas en diez minutos', r: 'todos', b: 'chispa', min: 15, xp: 15, img: 'g_idea', d: 'La primera idea es la más obvia. Saca diez.', s: ['Pon un cronómetro de 10 minutos.', 'Escribe 10 soluciones para tu problema: cambia el público, el material o pásalo de producto a servicio.', 'Encierra las 2 más locas y la más posible.'], e: 'Lista de 10 ideas.', g: 'Cap. 4' },
 { id: 'propuesta', t: 'Fórmula de propuesta de valor', r: 'con', b: 'chispa', min: 30, xp: 30, img: 'g_idea', d: 'Para quién, qué resuelve y por qué es mejor.', s: ['Usa el generador de la página de Herramientas.', 'Subraya las palabras que todavía son suposiciones.', 'Léela a alguien de otro curso: ¿la entiende en 15 segundos?'], e: 'Tu frase de propuesta de valor.', g: 'Cap. 4', tool: 'propuesta' },
 { id: 'nombres', t: 'Laboratorio de nombres', r: 'todos', b: 'marca', min: 45, xp: 30, img: 'g_marca', d: 'Crea 15 nombres y prueba los mejores con personas reales.', s: ['Usa el generador de nombres en Herramientas.', 'Elige 3 finalistas.', 'Pruébalos con 5 personas: ¿lo pronuncian bien? ¿lo recuerdan al día siguiente?'], e: 'Tabla de prueba con 5 personas.', g: 'Cap. 5', tool: 'nombres' },
 { id: 'brandboard', t: 'Mini brandboard', r: 'lid', b: 'marca', min: 60, xp: 35, img: 'g_marca', d: 'El sistema visual de tu proyecto en una página.', s: ['Elige 2 colores principales y 1 de acento.', 'Elige una letra para títulos y otra para texto.', 'Escribe tu propuesta de valor y 3 palabras de personalidad.', 'Revisa que no se parezca a otra marca.'], e: 'Brandboard en una hoja.', g: 'Cap. 5' },
 { id: 'carton', t: 'Prototipo de cartón en 30 minutos', r: 'exp', b: 'v1', min: 30, xp: 25, img: 'g_prototipo', d: 'Construye tu idea con papel, cartón y cinta.', s: ['Reúne materiales reutilizables.', 'Construye una versión rápida de tu idea (no tiene que ser bonita).', 'Muéstrasela a 2 personas y anota qué preguntan.'], e: 'Foto del prototipo.', g: 'Cap. 6' },
 { id: 'planv1', t: 'Plan de V1', r: 'con', b: 'v1', min: 40, xp: 30, img: 'g_prototipo', d: 'Un prototipo es una pregunta que puedes tocar.', s: ['Escribe la duda más importante que quieres resolver.', 'Define material, tiempo máximo y quién lo va a probar.', 'Decide qué vas a observar y una regla de seguridad.', 'Construye la V1 y anota qué cambiarías en la V2.'], e: 'Ficha de V1 + foto.', g: 'Cap. 6' },
 { id: 'tarjeta', t: 'Tarjeta de validación', r: 'lid', b: 'prueba', min: 45, xp: 35, img: 'g_validar', d: 'Decide antes qué resultado te haría cambiar de idea.', s: ['Escribe una hipótesis.', 'Diseña una prueba pequeña y justa.', 'Define 3 evidencias que vas a mirar.', 'Escribe qué harías si sale bien, regular o mal.'], e: 'Tarjeta completa.', g: 'Cap. 7' },
 { id: 'pruebajusta', t: 'Prueba justa con 5 personas', r: 'con', b: 'prueba', min: 60, xp: 35, img: 'g_validar', d: 'Observa si la gente usa tu idea, no si le gusta.', s: ['Explica lo mismo a cada persona.', 'Pídeles hacer una tarea con tu prototipo.', 'Cuenta cuántos la completan y anota lo que dicen.', 'Decide: seguir, mejorar, cambiar o pausar.'], e: 'Resultados y decisión.', g: 'Cap. 7' },
 { id: 'semaforo', t: 'Semáforo de fuentes', r: 'con', b: 'datos', min: 40, xp: 25, img: 'g_datos', d: 'No todo lo que está en internet es verdad.', s: ['Busca 3 fuentes sobre el tema de tu proyecto.', 'Para cada una anota autor, fecha y cómo obtuvo el dato.', 'Clasifícalas en verde, amarillo o rojo y explica por qué.'], e: 'Tabla de 3 fuentes.', g: 'Cap. 8' },
 { id: 'ipc', t: 'Tu IPC personal', r: 'todos', b: 'datos', min: 20, xp: 25, img: 'alza_papa', d: 'Del artículo de ALZA: mide tu propia inflación.', s: ['Elige 5 cosas que compras cada semana.', 'Anota su precio hoy.', 'Vuelve a mirarlo en 4 semanas y calcula cuánto subió cada una.', 'Usa la calculadora “¿Cuánto vale tu plata?”.'], e: 'Tabla de 5 precios, hoy y en un mes.', g: 'ALZA 01', tool: 'inflacion' },
 { id: 'detective', t: 'Detective de precios', r: 'exp', b: 'cuentas', min: 30, xp: 20, img: 'g_finanzas', d: '¿Cuánto cuesta de verdad hacer algo?', s: ['Elige algo sencillo (una tarjeta, una galleta, un separador).', 'Lista todo lo que se necesita para hacerlo.', 'Averigua el precio de cada cosa con ayuda de un adulto.', 'Suma: ¿cuánto cuesta hacer uno?'], e: 'Lista con precios.', g: 'Cap. 12' },
 { id: 'precio', t: 'Costo unitario y precio', r: 'con', b: 'cuentas', min: 40, xp: 35, img: 'g_finanzas', d: 'Vender mucho no es ganar. Haz la cuenta.', s: ['Usa la calculadora de precio en Herramientas.', 'Separa costos directos e indirectos.', 'Elige un precio y explica por qué es justo.'], e: 'Captura del cálculo.', g: 'Cap. 12', tool: 'precio' },
 { id: 'equilibrio', t: 'Punto de equilibrio', r: 'lid', b: 'cuentas', min: 40, xp: 35, img: 'alza_tasas', d: '¿Cuántas unidades necesitas vender para no perder?', s: ['Calcula tus costos fijos (los que pagas aunque no vendas).', 'Calcula el margen por unidad.', 'Divide: costos fijos ÷ margen. Ese es tu punto de equilibrio.', 'Pregúntate: ¿es realista vender eso?'], e: 'Cálculo y conclusión.', g: 'Cap. 12', tool: 'precio' },
 { id: 'presupuesto10k', t: 'Presupuesto del Reto 10K', r: 'con', b: 'k10', min: 45, xp: 40, img: 'alza_kiosko', d: 'Planea cada peso antes de gastarlo.', s: ['Usa el presupuesto 10K en Herramientas.', 'Agrega cada material con cantidad y costo.', 'Deja 10 % para imprevistos.', 'Revisa que no pases de $10.000.'], e: 'Presupuesto aprobado por tu mentor.', g: 'Kit · Reto 10K', tool: 'r10k' },
 { id: 'auditoria', t: 'Auditoría de residuos', r: 'todos', b: 'eco', min: 60, xp: 35, img: 'g_sostenible', d: 'Sin medición no hay EcoReto.', s: ['Con guantes y un adulto, mide durante 3 días un residuo del colegio.', 'Anota peso o cantidad por día.', 'Haz una gráfica sencilla.', 'Propón una solución y mide otra vez.'], e: 'Datos antes y después.', g: 'Cap. 16' },
 { id: 'radar', t: 'Radar de impacto', r: 'lid', b: 'eco', min: 40, xp: 30, img: 'g_sostenible', d: '¿A quién ayuda y a quién podría afectar tu idea?', s: ['Evalúa tu idea en personas, ambiente, datos, dinero y convivencia.', 'Para cada uno escribe un beneficio, un riesgo y una mejora.'], e: 'Radar completo.', g: 'Cap. 16' },
 { id: 'afiche', t: 'Afiche de stand', r: 'todos', b: 'mercado', min: 45, xp: 25, img: 'g_marketing', d: 'Tu proyecto en un afiche que se entienda en 5 segundos.', s: ['Nombre grande, problema en una frase y foto o dibujo del prototipo.', 'Un dato de tus pruebas.', 'Un llamado a la acción: “Pruébalo”, “Vota por nosotros”.'], e: 'Foto del afiche.', g: 'Cap. 10' },
 { id: 'dialogo', t: 'Diálogo de venta ética', r: 'con', b: 'mercado', min: 30, xp: 25, img: 'alza_kiosko', d: 'Vender es ayudar a decidir, no presionar.', s: ['Escribe: saludo, dos preguntas, explicación, una objeción y respuesta honesta.', 'Practícalo con alguien que haga de cliente difícil.', 'Cambien de rol.'], e: 'Guion escrito.', g: 'Cap. 11' },
 { id: 'gancho', t: 'Tu gancho en una frase', r: 'todos', b: 'pitch', min: 20, xp: 20, img: 'g_pitch', d: 'Los primeros 20 segundos deciden si te escuchan.', s: ['Empieza con una persona, una escena o un dato sorprendente.', 'Escribe 3 versiones.', 'Léelas a 3 personas y quédate con la que más reacción genere.'], e: 'Tu mejor gancho.', g: 'Cap. 17' },
 { id: 'pitch3', t: 'Pitch de 3 minutos cronometrado', r: 'lid', b: 'pitch', min: 60, xp: 50, img: 'g_pitch', d: 'Ensaya con el cronómetro de 7 etapas.', s: ['Abre el cronómetro de pitch en Herramientas.', 'Ensaya 3 veces frente a alguien que no conozca el proyecto.', 'Prepara respuestas a 5 preguntas difíciles.'], e: 'Video o nota de tu mejor tiempo.', g: 'Cap. 17', tool: 'pitch' },
];

function initRetos() {
  let done = store.get('done', {});
  let filter = 'todas';
  const grid = $('#retos-grid');
  function render() {
    grid.innerHTML = RETOS.filter(r => filter === 'todas' || r.r === filter || r.r === 'todos').map(r => `
      <article class="card reto ${done[r.id] ? 'done' : ''}" id="r-${r.id}">
        <div class="donebadge">✓ Completado</div>
        <div class="img" style="background-image:url('assets/img/${r.img}.webp')"></div>
        <div class="body">
          <div class="meta"><span class="pill">${RUTAS[r.r]}</span><span class="pill">${r.min} min</span><span class="pill">+${r.xp} XP</span><span class="pill">Insignia ${BADGES[r.b]}</span></div>
          <h3>${r.t}</h3>
          <p class="small">${r.d}</p>
          <details><summary>Ver pasos</summary><ol class="small">${r.s.map(x => `<li>${x}</li>`).join('')}</ol>
            <p class="small"><b>Evidencia:</b> ${r.e}<br><b>En La Guía:</b> ${r.g}</p></details>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:auto;padding-top:8px">
            <button class="btn sm ${done[r.id] ? 'ghost' : ''}" data-id="${r.id}">${done[r.id] ? 'Desmarcar' : 'Marcar completado'}</button>
            ${r.tool ? `<a class="btn sm alt" href="herramientas.html#${r.tool}">Herramienta</a>` : ''}
            <button class="btn sm ghost" data-ev="${r.id}">Enviar evidencia</button>
          </div>
        </div>
      </article>`).join('');
    $$('button[data-id]', grid).forEach(b => b.onclick = () => {
      const id = b.dataset.id;
      if (done[id]) delete done[id]; else { done[id] = new Date().toISOString().slice(0, 10); toast('¡Reto completado! +' + RETOS.find(r => r.id === id).xp + ' XP'); }
      store.set('done', done); render(); passport(); syncProgress();
    });
    $$('button[data-ev]', grid).forEach(b => b.onclick = () => openEvidence(RETOS.find(r => r.id === b.dataset.ev)));
  }
  function syncProgress() {
    if (!api.on() || !nm.value.trim()) return;
    const ids = Object.keys(done);
    api.post({ type: 'progreso', nombre: nm.value.trim(), grado: ($('#pgrado').value || '').trim(), ruta: RUTAS[rt.value], xp: RETOS.filter(r => done[r.id]).reduce((a, r) => a + r.xp, 0), retos: ids.join(', ') }).then(loadRanking).catch(() => {});
  }
  async function loadRanking() {
    const box = $('#ranking'); if (!box) return;
    if (!api.on()) { box.innerHTML = '<p class="small muted">El ranking del comité aparece cuando se conecta la base de datos de Google Sheets.</p>'; return; }
    try {
      const rows = await api.get('ranking');
      box.innerHTML = rows.length ? '<ol class="rank">' + rows.map(r => `<li><span>${esc(r.nombre)}</span><b>${r.xp} XP</b></li>`).join('') + '</ol>' : '<p class="small muted">Todavía no hay puntajes. ¡Sé la primera persona!</p>';
    } catch (e) { box.innerHTML = '<p class="small muted">No se pudo cargar el ranking ahora.</p>'; }
  }
  function openEvidence(r) {
    const m = $('#evmodal'); $('#ev_reto').textContent = r.t; m.hidden = false; $('#ev_name').value = nm.value; $('#ev_msg').textContent = '';
    $('#ev_send').onclick = async () => {
      const d = { type: 'evidencia', reto: r.t, nombre: $('#ev_name').value.trim(), grado: $('#ev_grado').value.trim(), equipo: $('#ev_equipo').value.trim(), enlace: $('#ev_link').value.trim(), comentario: $('#ev_com').value.trim() };
      if (!d.nombre || !d.enlace) { $('#ev_msg').textContent = 'Escribe tu nombre y el enlace a tu evidencia (Drive, foto o documento).'; return; }
      if (api.on()) {
        try { await api.post(d); $('#ev_msg').textContent = 'Evidencia enviada a la base de datos del comité.'; setTimeout(() => m.hidden = true, 1400); }
        catch (e) { $('#ev_msg').textContent = 'No se pudo enviar. Revisa tu conexión e inténtalo de nuevo.'; }
      } else {
        const body = Object.entries(d).filter(([k]) => k !== 'type').map(([k, v]) => `${k}: ${v}`).join('\n');
        location.href = `mailto:${CONFIG.email}?subject=${encodeURIComponent('Evidencia reto: ' + r.t)}&body=${encodeURIComponent(body)}`;
        $('#ev_msg').textContent = 'Se abrió tu correo. Si no se abrió, escribe a ' + CONFIG.email;
      }
    };
  }
  $('#ev_close').onclick = () => $('#evmodal').hidden = true;
  function passport() {
    const xp = RETOS.filter(r => done[r.id]).reduce((a, r) => a + r.xp, 0);
    const total = RETOS.reduce((a, r) => a + r.xp, 0);
    const got = new Set(RETOS.filter(r => done[r.id]).map(r => r.b));
    $('#xp').textContent = xp; $('#xpmax').textContent = total;
    $('#nretos').textContent = Object.keys(done).length;
    $('#nbadges').textContent = got.size;
    $('#bar').style.width = Math.round(100 * xp / total) + '%';
    $('#badges').innerHTML = Object.entries(BADGES).map(([k, v]) => `<div class="badge ${got.has(k) ? 'on' : ''}">${v}</div>`).join('');
    const lvl = xp >= 500 ? 'Líder M·LAB' : xp >= 250 ? 'Constructor/a' : xp >= 80 ? 'Explorador/a' : 'Recién llegado/a';
    $('#nivel').textContent = lvl;
  }
  const nm = $('#pname'); nm.value = store.get('name', ''); nm.oninput = () => store.set('name', nm.value);
  const rt = $('#pruta'); rt.value = store.get('ruta', 'exp'); rt.onchange = () => store.set('ruta', rt.value);
  const gr = $('#pgrado'); gr.value = store.get('grado', ''); gr.oninput = () => store.set('grado', gr.value);
  $('#syncp').onclick = () => { if (!api.on()) { toast('La base de datos aún no está conectada'); return; } if (!nm.value.trim()) { toast('Escribe tu nombre primero'); return; } syncProgress(); toast('Progreso guardado en el ranking'); };
  $$('.chip').forEach(c => c.onclick = () => { $$('.chip').forEach(x => x.classList.remove('on')); c.classList.add('on'); filter = c.dataset.f; render(); });
  $('#exportp').onclick = () => {
    const name = nm.value || 'Estudiante';
    const lines = RETOS.filter(r => done[r.id]).map(r => `• ${r.t} (${done[r.id]})`).join('\n');
    const txt = `Pasaporte M·LAB — ${name}\nRuta: ${RUTAS[rt.value]}\nXP: ${$('#xp').textContent}\nRetos completados:\n${lines || '—'}`;
    navigator.clipboard?.writeText(txt).then(() => toast('Resumen copiado. Pégalo en tu bitácora o envíalo a tu mentor.'), () => alert(txt));
  };
  $('#resetp').onclick = () => { if (confirm('¿Borrar tu progreso en este navegador?')) { done = {}; store.set('done', done); render(); passport(); } };
  render(); passport(); loadRanking();
}

/* ---------------- HERRAMIENTAS ---------------- */
function initTools() {
  // Precio y punto de equilibrio
  const P = () => {
    const v = id => parseFloat(($('#' + id).value || '0').replace(/\./g, '').replace(',', '.')) || 0;
    const dir = v('p_dir'), fijos = v('p_fijos'), unid = Math.max(1, v('p_unid')), mg = v('p_margen') / 100;
    const cu = dir + fijos / unid;
    const precio = cu / (1 - Math.min(mg, .95));
    const margenU = precio - dir;
    const pe = margenU > 0 ? Math.ceil(fijos / margenU) : Infinity;
    $('#p_out').innerHTML = `<div class="tag" style="color:var(--yellow)">Precio sugerido</div><div class="big">${fmt(Math.ceil(precio / 50) * 50)}</div>
      <p class="mt1">Costo por unidad: <b>${fmt(cu)}</b> · Ganancia por unidad (sobre costo directo): <b>${fmt(margenU)}</b><br>Punto de equilibrio: <b>${isFinite(pe) ? pe + ' unidades' : '—'}</b> para cubrir ${fmt(fijos)} de costos fijos.</p>
      <p class="small muted mt1">Antes de decidir: ¿ese precio es justo para tu usuario? ¿Cuánto cuestan las alternativas?</p>`;
  };
  $$('#precio input').forEach(i => i.oninput = P); P();

  // Presupuesto 10K
  const tb = $('#r_rows');
  const addRow = (c = '', q = 1, u = 0) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td><input value="${c}" placeholder="Material"></td><td><input type="number" min="0" value="${q}" style="width:80px"></td><td><input type="number" min="0" value="${u}" style="width:110px"></td><td class="tot"></td><td><button class="chip" title="Quitar">✕</button></td>`;
    tb.appendChild(tr); $$('input', tr).forEach(i => i.oninput = R); $('button', tr).onclick = () => { tr.remove(); R(); }; R();
  };
  const R = () => {
    let s = 0; $$('tr', tb).forEach(tr => { const [, q, u] = $$('input', tr).map(i => parseFloat(i.value) || 0); const t = q * u; s += t; $('.tot', tr).textContent = fmt(t); });
    const c = Math.round(s * .1), tot = s + c, left = 10000 - tot;
    $('#r_out').innerHTML = `Subtotal <b>${fmt(s)}</b> · Imprevistos 10 % <b>${fmt(c)}</b><div class="big" style="color:${left < 0 ? 'var(--red)' : 'var(--yellow)'}">${fmt(tot)}</div><p>${left >= 0 ? `Te quedan ${fmt(left)} de los $10.000.` : `Te pasaste por ${fmt(-left)}. Ajusta cantidades o busca materiales reutilizables.`}</p>`;
  };
  $('#r_add').onclick = () => addRow();
  addRow('Papel reutilizado autorizado', 20, 0); addRow('Grapas (caja)', 1, 2500); addRow('Cartulina para portadas', 2, 1500);

  // Propuesta de valor
  const V = () => {
    const g = id => $('#' + id).value.trim() || `[${$('#' + id).placeholder}]`;
    $('#v_out').innerHTML = `<p class="deck" style="color:var(--cream)">Para <b>${g('v1')}</b> que necesita <b>${g('v2')}</b>, ofrecemos <b>${g('v3')}</b> que ayuda a <b>${g('v4')}</b>, a diferencia de <b>${g('v5')}</b>, porque <b>${g('v6')}</b>.</p><p class="small muted mt1">Recuerda: es una hipótesis. Subraya lo que todavía no has comprobado.</p>`;
  };
  $$('#propuesta input').forEach(i => i.oninput = V); V();
  $('#v_copy').onclick = () => navigator.clipboard?.writeText($('#v_out p').innerText).then(() => toast('Copiado'));

  // Nombres
  $('#n_go').onclick = () => {
    const words = $('#n_words').value.split(/[,\n]/).map(w => w.trim()).filter(Boolean);
    if (words.length < 2) { toast('Escribe al menos 2 palabras separadas por coma'); return; }
    const suf = ['ito', 'ia', 'lab', 'ix', 'go', 'ly', 'a', 'o'], pre = ['Eco', 'Mini', 'Super', 'Nova', 'Re', 'Mi', 'Pro', 'Co'];
    const out = new Set(); const cap = s => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
    let guard = 0;
    while (out.size < 15 && guard++ < 400) {
      const a = words[Math.floor(Math.random() * words.length)], b = words[Math.floor(Math.random() * words.length)];
      const k = Math.random();
      let n = k < .3 ? cap(a) + cap(b) : k < .5 ? cap(a.slice(0, Math.ceil(a.length / 2)) + b.slice(Math.floor(b.length / 2))) : k < .7 ? pre[Math.floor(Math.random() * pre.length)] + cap(a) : k < .85 ? cap(a) + suf[Math.floor(Math.random() * suf.length)] : cap(a) + ' & ' + cap(b);
      if (a !== b || k > .5) out.add(n);
    }
    $('#n_out').innerHTML = [...out].map(n => `<label style="display:flex;gap:8px;align-items:center;font-weight:600;margin:6px 0"><input type="checkbox" style="width:auto"> ${n}</label>`).join('') + '<p class="small muted mt1">Marca tus 3 favoritos y pruébalos con 5 personas: ¿lo pronuncian bien? ¿lo recuerdan mañana? Revisa que no exista ya.</p>';
  };

  // Matriz de decisión
  const crit = ['Utilidad', 'Seguridad', 'Costo', 'Tiempo', 'Aprendizaje'];
  $('#m_table').innerHTML = `<tr><th>Criterio</th><th>Peso</th><th><input id="m_n1" value="Idea A"></th><th><input id="m_n2" value="Idea B"></th><th><input id="m_n3" value="Idea C"></th></tr>` +
    crit.map((c, i) => `<tr><td><b>${c}</b></td><td><input type="number" min="1" max="3" value="1" data-w="${i}" style="width:64px"></td>${[0, 1, 2].map(j => `<td><input type="number" min="1" max="5" value="3" data-c="${i}" data-j="${j}" style="width:72px"></td>`).join('')}</tr>`).join('');
  const Mx = () => {
    const w = $$('[data-w]').map(i => +i.value || 1); const s = [0, 0, 0];
    $$('[data-c]').forEach(i => s[+i.dataset.j] += (+i.value || 0) * w[+i.dataset.c]);
    const names = [1, 2, 3].map(k => $('#m_n' + k).value); const best = s.indexOf(Math.max(...s));
    $('#m_out').innerHTML = names.map((n, k) => `<div style="display:flex;justify-content:space-between"><span>${n}</span><b>${s[k]} pts</b></div>`).join('') + `<p class="mt1">Gana <b style="color:var(--yellow)">${names[best]}</b>. Pero ojo: la tabla ayuda a conversar, no decide por ustedes.</p>`;
  };
  $$('#matriz input').forEach(i => i.oninput = Mx); Mx();

  // Pitch timer
  const ST = [['Gancho', 20], ['Problema', 30], ['Solución', 30], ['Evidencia', 40], ['Cómo funciona', 30], ['Equipo y necesidad', 20], ['Cierre', 10]];
  const total = ST.reduce((a, s) => a + s[1], 0);
  let t = 0, iv = null;
  const draw = () => {
    const left = total - t; $('#t_clock').textContent = `${Math.floor(left / 60)}:${String(left % 60).padStart(2, '0')}`;
    let acc = 0; $('#t_stages').innerHTML = ST.map(([n, d]) => { const st = acc; acc += d; const cls = t >= acc ? 'past' : t >= st ? 'now' : ''; return `<div class="stage ${cls}"><span>${n}</span><b>${d}s</b></div>`; }).join('');
  };
  $('#t_start').onclick = () => { if (iv) return; iv = setInterval(() => { t++; if (t >= total) { clearInterval(iv); iv = null; toast('¡Tiempo! Cierra con una frase.'); } draw(); }, 1000); };
  $('#t_pause').onclick = () => { clearInterval(iv); iv = null; };
  $('#t_reset').onclick = () => { clearInterval(iv); iv = null; t = 0; draw(); };
  draw();

  // Entrevista
  $('#e_go').onclick = () => {
    const p = $('#e_prob').value.trim() || 'el problema';
    const qs = [`Cuéntame la última vez que te pasó algo relacionado con ${p}.`, '¿Qué hiciste en ese momento?', '¿Qué fue lo más difícil o molesto?', '¿Has probado alguna solución? ¿Qué tal funcionó?', '¿Qué tendría que pasar para que confiaras en una solución nueva?', '¿Qué no debería pasar nunca?', '¿Hay algo más que no te haya preguntado y sea importante?'];
    $('#e_out').innerHTML = '<ol style="padding-left:20px">' + qs.map(q => `<li style="margin:6px 0">${q}</li>`).join('') + '</ol><p class="small muted mt1">Evita: “¿Comprarías…?”, “¿Te gusta mi idea?” y preguntas de sí/no. Usa códigos como “Persona A”.</p>';
  };

  // Inflación / interés
  const F = () => {
    const m = parseFloat($('#i_monto').value) || 0, inf = (parseFloat($('#i_inf').value) || 0) / 100, ti = (parseFloat($('#i_tasa').value) || 0) / 100, y = parseFloat($('#i_anos').value) || 1;
    const real = m / Math.pow(1 + inf, y), ahorro = m * Math.pow(1 + ti, y), ahorroReal = ahorro / Math.pow(1 + inf, y);
    $('#i_out').innerHTML = `<p>Si guardas ${fmt(m)} debajo del colchón ${y} año(s), compra lo mismo que hoy <b>${fmt(real)}</b>.</p><div class="big">${fmt(ahorroReal - m)}</div><p>es lo que ganarías (o perderías, si es negativo) en poder de compra ahorrando al ${(ti * 100).toFixed(1)} % anual con inflación de ${(inf * 100).toFixed(2)} %.</p><p class="small muted mt1">Calculadora educativa. Datos de referencia: inflación Colombia 6,24 % (agosto 2026, DANE).</p>`;
  };
  $$('#inflacion input').forEach(i => i.oninput = F); F();
}

/* ---------------- ÚNETE ---------------- */
function initJoin() {
  $$('[data-form]').forEach(a => a.href = CONFIG.formUrl);
  $$('[data-email]').forEach(a => { a.textContent = CONFIG.email; a.href = 'mailto:' + CONFIG.email; });
  const c = $('#copymail'); if (c) c.onclick = () => navigator.clipboard?.writeText(CONFIG.email).then(() => toast('Correo copiado'));
}
