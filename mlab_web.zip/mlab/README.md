# Web M·LAB — mrestudiantil.vercel.app

Sitio estático (HTML + CSS + JS) del Comité de Emprendimiento e Innovación del Colegio Monterrosales.
Líderes: Isabella Hermosa Osma y Karen Ariza · comite_estudiantil_mrhs@monterrosaleshomeschool.edu.co · @somosmonterrosales

## Ya viene configurado
- Inscripción: https://forms.gle/gKAMfk2FQ1c8C2Ch9
- Correo del comité para evidencias y dudas.
- Logos de M·LAB y del Colegio Monterrosales en todas las páginas.
- Base de datos opcional en Google Sheets (ranking + evidencias): ver `BASE_DE_DATOS_Google_Sheets.md`.

## Publicar dentro de mrestudiantil.vercel.app (recomendado)
mrestudiantil.vercel.app ya es la plataforma del Consejo Estudiantil (8 comités, cuentas, agenda). Para no reemplazarla, M·LAB se publica **dentro** de ella, en **mrestudiantil.vercel.app/mlab/**. Todas las rutas de esta carpeta son relativas, así que funciona en esa subcarpeta sin cambios.

1. Abre el código del proyecto `mrestudiantil` (el repositorio de GitHub conectado a Vercel).
2. Copia esta carpeta completa con el nombre **`mlab`**:
   - Si el proyecto tiene carpeta `public/` (Next.js, Vite, React): ponla en `public/mlab/`.
   - Si es HTML estático: ponla en la raíz del proyecto, como `mlab/`.
3. En la tarjeta **Emprendimiento e Innovación**, cambia el enlace “Ver más →” a `/mlab/`.
4. Haz commit y push. Vercel publica solo. Abre https://mrestudiantil.vercel.app/mlab/

## Opción B: proyecto aparte
vercel.com → Add New → Project → sube esta carpeta (Framework Preset: Other, sin build). Quedará en una dirección propia, por ejemplo `mlab-monterrosales.vercel.app`, y se enlaza desde el consejo.

## Páginas
index (inicio) · programa · ruta y retos (4 etapas, 25 misiones con lección, checklist, quiz y bitácora) · libro (La Guía en línea) · herramientas (15) · revista (ALZA y La Guía) · unete (inscripción)
