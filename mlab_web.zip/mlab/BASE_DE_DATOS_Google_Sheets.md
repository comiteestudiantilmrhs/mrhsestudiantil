# Base de datos de la web M·LAB (Google Sheets) — opcional, 10 minutos

La web **ya funciona sin base de datos**: la inscripción va al Formulario de Google del comité (las respuestas quedan en su hoja de cálculo) y las evidencias se envían por correo a comite_estudiantil_mrhs@monterrosaleshomeschool.edu.co.

Si además quieren **ranking del comité** y **evidencias guardadas en una hoja**, conecten Google Sheets así:

1. Con la cuenta del comité, crea una hoja de cálculo nueva llamada **“M·LAB · Base de datos web”**.
2. Menú **Extensiones → Apps Script**. Borra lo que aparece y pega todo el contenido de `base_de_datos/Code.gs`. Guarda.
3. Botón **Implementar → Nueva implementación** → tipo **Aplicación web**.
   - Ejecutar como: **Yo** (la cuenta del comité)
   - Quién tiene acceso: **Cualquier usuario**
4. Autoriza los permisos y copia la **URL de la aplicación web** (termina en `/exec`).
5. Abre `assets/js/app.js` y pégala en `apiUrl: ''` (entre las comillas).
6. Vuelve a subir la web a Vercel.

Listo: aparecerán las pestañas **Evidencias** y **Progreso** en la hoja. El ranking público muestra solo nombre + inicial del apellido y los XP. Coordinación revisa las evidencias y marca la columna “Revisado”.
