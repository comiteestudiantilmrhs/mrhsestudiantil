/**
 * M·LAB · Base de datos en Google Sheets para mrestudiantil.vercel.app
 * Guarda evidencias de retos y el progreso (ranking) de cada estudiante.
 * Pegar en: Hoja de cálculo > Extensiones > Apps Script. Luego Implementar > Aplicación web.
 */
const HOJA_EVIDENCIAS = 'Evidencias';
const HOJA_PROGRESO = 'Progreso';

function hoja_(nombre, encabezados) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(nombre);
  if (!sh) { sh = ss.insertSheet(nombre); sh.appendRow(encabezados); sh.setFrozenRows(1); }
  return sh;
}
function limpio_(v, max) { return String(v || '').replace(/^[=+\-@]/, "'").slice(0, max || 500); }

function doPost(e) {
  const lock = LockService.getScriptLock(); lock.waitLock(10000);
  try {
    const d = JSON.parse(e.postData.contents || '{}');
    if (d.type === 'evidencia') {
      hoja_(HOJA_EVIDENCIAS, ['Fecha', 'Reto', 'Nombre', 'Grado', 'Equipo', 'Enlace', 'Aprendizaje', 'Revisado'])
        .appendRow([new Date(), limpio_(d.reto, 120), limpio_(d.nombre, 80), limpio_(d.grado, 20), limpio_(d.equipo, 80), limpio_(d.enlace, 400), limpio_(d.comentario, 1000), '']);
    } else if (d.type === 'progreso') {
      const sh = hoja_(HOJA_PROGRESO, ['Nombre', 'Grado', 'Ruta', 'XP', 'Retos', 'Actualizado']);
      const nombre = limpio_(d.nombre, 80), grado = limpio_(d.grado, 20);
      const datos = sh.getDataRange().getValues();
      let fila = -1;
      for (let i = 1; i < datos.length; i++) if (datos[i][0] === nombre && String(datos[i][1]) === grado) { fila = i + 1; break; }
      const valores = [nombre, grado, limpio_(d.ruta, 30), Math.max(0, Math.min(2000, Number(d.xp) || 0)), limpio_(d.retos, 1000), new Date()];
      if (fila > 0) sh.getRange(fila, 1, 1, 6).setValues([valores]); else sh.appendRow(valores);
    }
    return ContentService.createTextOutput(JSON.stringify({ ok: true })).setMimeType(ContentService.MimeType.JSON);
  } finally { lock.releaseLock(); }
}

function doGet(e) {
  if ((e.parameter.action || '') === 'ranking') {
    const sh = hoja_(HOJA_PROGRESO, ['Nombre', 'Grado', 'Ruta', 'XP', 'Retos', 'Actualizado']);
    const filas = sh.getDataRange().getValues().slice(1)
      .map(r => ({ nombre: String(r[0]).split(' ')[0] + (String(r[0]).split(' ')[1] ? ' ' + String(r[0]).split(' ')[1][0] + '.' : ''), xp: Number(r[3]) || 0 }))
      .sort((a, b) => b.xp - a.xp).slice(0, 15);
    return ContentService.createTextOutput(JSON.stringify(filas)).setMimeType(ContentService.MimeType.JSON);
  }
  return ContentService.createTextOutput(JSON.stringify({ ok: true, servicio: 'M·LAB' })).setMimeType(ContentService.MimeType.JSON);
}
