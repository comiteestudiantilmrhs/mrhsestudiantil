/* M·LAB · Ruta de aprendizaje interactiva, misiones, libro y bitácora. Usa globales de app.js y guia.js. */
const ETAPAS = [
  { k: 1, n: 'Descubre', c: 'var(--aqua)', caps: [1, 2, 3] },
  { k: 2, n: 'Diseña', c: 'var(--yellow)', caps: [4, 5, 6, 7] },
  { k: 3, n: 'Organiza', c: 'var(--orange)', caps: [8, 9, 10, 11, 12, 13, 14] },
  { k: 4, n: 'Crece', c: 'var(--lav)', caps: [15, 16, 17] },
];
const CAP_EXTRA = { 'ALZA 01': 8, 'Kit · Reto 10K': 12 };
const capOf = r => CAP_EXTRA[r.g] || parseInt((r.g.match(/\d+/) || [1])[0], 10);
const etapaOf = r => ETAPAS.find(e => e.caps.includes(capOf(r))).k;
// Una pregunta de comprensión por capítulo [pregunta, opciones, índice correcto, explicación]
const QUIZ = {
  1: ['¿Qué significa emprender en M·LAB?', ['Hacerse rico rápido', 'Resolver una necesidad creando valor', 'Tener un logo bonito'], 1, 'Emprender es un proceso para crear valor; la plata y el logo vienen después.'],
  2: ['Hay papel en el piso del salón. Eso es…', ['La causa', 'El síntoma', 'La solución'], 1, 'Lo que ves es el síntoma; la causa explica por qué pasa.'],
  3: ['¿Cuál es una buena pregunta de entrevista?', ['¿Comprarías mi producto?', '¿Te gusta mi idea?', 'Cuéntame la última vez que te pasó…'], 2, 'Pregunta por hechos reales del pasado, no por opiniones sobre tu idea.'],
  4: ['Una propuesta de valor es…', ['Una hipótesis que debes probar', 'Una verdad comprobada', 'El precio del producto'], 0, 'Hasta que la pruebes con personas, es una apuesta.'],
  5: ['¿Qué es greenwashing?', ['Lavar con productos ecológicos', 'Decir que algo es ecológico sin poder demostrarlo', 'Un color de marca'], 1, 'Solo promete lo que puedes probar.'],
  6: ['Un prototipo sirve para…', ['Vender la versión final', 'Responder una duda rápido y barato', 'Impresionar al jurado'], 1, 'Es una pregunta que puedes tocar.'],
  7: ['Validar es…', ['Pedir que feliciten tu idea', 'Buscar evidencia para decidir', 'Contar likes'], 1, 'Un resultado “malo” también es un buen dato.'],
  8: ['“7 de 10 usuarios terminaron la tarea” es…', ['Un dato suelto', 'Información con contexto', 'Una opinión'], 1, 'El contexto convierte el dato en información.'],
  9: ['La IA en M·LAB es…', ['El piloto que decide', 'Un copiloto que verificas', 'Prohibida'], 1, 'Úsala, di que la usaste y revisa todo.'],
  10: ['Marketing es…', ['Convencer a cualquiera', 'Conectar valor con la persona adecuada', 'Publicar todos los días “compra ya”'], 1, 'Primero a quién ayudas, luego cómo lo cuentas.'],
  11: ['Una objeción del cliente es…', ['Un ataque', 'Una duda que hay que entender', 'Una razón para insistir'], 1, 'Pregunta, explica con honestidad y acepta un no.'],
  12: ['Cuesta $3.000 hacer uno y lo vendes a $2.500. Si vendes más…', ['Ganas más', 'Pierdes más', 'Quedas igual'], 1, 'Cada unidad te deja $500 de pérdida.'],
  13: ['Calidad significa…', ['Perfección', 'Cumplir los criterios siempre', 'Usar materiales caros'], 1, 'Define antes qué es “bien hecho”.'],
  14: ['Si una sola persona tiene todos los archivos…', ['El equipo está seguro', 'El proyecto corre riesgo', 'Es más rápido y mejor'], 1, 'La información no debe depender de una sola persona.'],
  15: ['Antes de votar entre ideas conviene…', ['Definir criterios', 'Que decida el que habla más', 'Lanzar una moneda'], 0, 'Una matriz con criterios evita peleas de gustos.'],
  16: ['“Reciclable” significa que…', ['Siempre será reciclado', 'Podría reciclarse, pero no está garantizado', 'Es 100 % ecológico'], 1, 'Piensa en el ciclo completo del producto.'],
  17: ['Un buen pitch empieza con…', ['“Nuestro proyecto se llama…”', 'Una persona, una escena o un dato', 'La lista del equipo'], 1, 'Las historias se recuerdan; las listas no.'],
};
const L = {
  done: store.get('done', {}), steps: store.get('steps', {}), notes: store.get('notes', {}), read: store.get('read', {}),
  save() { store.set('done', this.done); store.set('steps', this.steps); store.set('notes', this.notes); store.set('read', this.read); }
};
const xpOf = () => RETOS.filter(r => L.done[r.id]).reduce((a, r) => a + r.xp, 0);
const unlocked = k => k === 1 || RETOS.filter(r => etapaOf(r) === k - 1 && L.done[r.id]).length >= 2;

function confetti() {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const box = document.createElement('div'); box.className = 'confetti';
  const cols = ['#F26B1D', '#F2B33D', '#7CC6BE', '#E8312A', '#C7B5F0', '#DDF34A'];
  for (let i = 0; i < 80; i++) { const s = document.createElement('i'); s.style.cssText = `left:${Math.random() * 100}%;background:${cols[i % 6]};animation-delay:${Math.random() * .4}s;animation-duration:${1.4 + Math.random()}s;transform:rotate(${Math.random() * 360}deg)`; box.appendChild(s); }
  document.body.appendChild(box); setTimeout(() => box.remove(), 2800);
}

/* ---------- RUTA ---------- */
function initRuta() {
  const ruta = $('#ruta'); if (!ruta) return;
  const nm = $('#pname'), rt = $('#pruta'), gr = $('#pgrado');
  nm.value = store.get('name', ''); nm.oninput = () => store.set('name', nm.value);
  rt.value = store.get('ruta', 'exp'); rt.onchange = () => { store.set('ruta', rt.value); draw(); };
  gr.value = store.get('grado', ''); gr.oninput = () => store.set('grado', gr.value);
  let filtro = 'todas';
  $$('.chip[data-f]').forEach(c => c.onclick = () => { $$('.chip[data-f]').forEach(x => x.classList.remove('on')); c.classList.add('on'); filtro = c.dataset.f; draw(); });

  function passport() {
    const xp = xpOf(), total = RETOS.reduce((a, r) => a + r.xp, 0), got = new Set(RETOS.filter(r => L.done[r.id]).map(r => r.b));
    $('#xp').textContent = xp; $('#xpmax').textContent = total; $('#nretos').textContent = Object.keys(L.done).length; $('#nbadges').textContent = got.size;
    $('#bar').style.width = Math.round(100 * xp / total) + '%';
    $('#badges').innerHTML = Object.entries(BADGES).map(([k, v]) => `<div class="badge ${got.has(k) ? 'on' : ''}" title="Insignia ${v}">${v}</div>`).join('');
    $('#nivel').textContent = xp >= 500 ? 'Líder M·LAB' : xp >= 250 ? 'Constructor/a' : xp >= 80 ? 'Explorador/a' : 'Recién llegado/a';
    const next = RETOS.find(r => !L.done[r.id] && unlocked(etapaOf(r)) && (r.r === rt.value || r.r === 'todos'));
    $('#siguiente').innerHTML = next ? `Tu siguiente misión: <button class="linkish" data-open="${next.id}">${next.t} →</button>` : '¡Completaste todo lo disponible para tu ruta!';
    $$('[data-open]', $('#siguiente')).forEach(b => b.onclick = () => openMision(b.dataset.open));
  }
  function draw() {
    ruta.innerHTML = ETAPAS.map(e => {
      const rs = RETOS.filter(r => etapaOf(r) === e.k && (filtro === 'todas' || r.r === filtro || r.r === 'todos'));
      const hechos = RETOS.filter(r => etapaOf(r) === e.k && L.done[r.id]).length, tot = RETOS.filter(r => etapaOf(r) === e.k).length;
      const open = unlocked(e.k);
      return `<section class="etapa ${open ? '' : 'locked'}" style="--ec:${e.c}">
        <header class="etapa-h"><div class="etapa-n">${String(e.k).padStart(2, '0')}</div><div><h3>${e.n}</h3><p class="small">${PARTES[e.k].q}</p></div>
        <div class="etapa-p"><b>${hechos}/${tot}</b><div class="progress"><span style="width:${100 * hechos / tot}%"></span></div></div></header>
        ${open ? '' : `<p class="lockmsg">🔒 Completa 2 misiones de ${ETAPAS[e.k - 2].n} para desbloquear esta etapa.</p>`}
        <div class="nodos">${rs.map((r, i) => `<button class="nodo ${L.done[r.id] ? 'ok' : ''}" data-open="${r.id}" ${open ? '' : 'disabled'}>
          <span class="dot">${L.done[r.id] ? '✓' : i + 1}</span><span class="nt"><b>${r.t}</b><small>${RUTAS[r.r]} · ${r.min} min · +${r.xp} XP</small></span>
          ${stepsDone(r) ? `<span class="mini">${stepsDone(r)}/${r.s.length}</span>` : ''}</button>`).join('')}</div>
      </section>`;
    }).join('');
    $$('[data-open]', ruta).forEach(b => b.onclick = () => openMision(b.dataset.open));
    passport();
  }
  const stepsDone = r => (L.steps[r.id] || []).filter(Boolean).length;

  /* ---------- MISIÓN (lección + checklist + quiz + bitácora) ---------- */
  function openMision(id) {
    const r = RETOS.find(x => x.id === id), cap = GUIA.find(c => c.n === capOf(r)), q = QUIZ[cap.n];
    const st = L.steps[id] || r.s.map(() => false);
    const m = $('#mision');
    m.innerHTML = `<div class="mpanel" role="dialog" aria-labelledby="m_t">
      <button class="mclose" aria-label="Cerrar">✕</button>
      <div class="mhead" style="background-image:url('assets/img/${r.img}.webp')"><span class="kicker fill">Misión · Insignia ${BADGES[r.b]}</span></div>
      <div class="mbody">
        <h2 id="m_t">${r.t}</h2><p class="deck mt1">${r.d}</p>
        <div class="tabs mt2" role="tablist"><button class="tab on" data-t="1">1 · Aprende</button><button class="tab" data-t="2">2 · Haz</button><button class="tab" data-t="3">3 · Comprueba</button><button class="tab" data-t="4">4 · Registra</button></div>
        <div class="tp" data-p="1">
          <div class="box navy mt2"><div class="tag" style="color:var(--yellow)">En 10 segundos · Cap. ${cap.n}</div><p class="mt1">${cap.tldr}</p></div>
          <div class="box yellow mt1"><div class="tag">Lo que nadie te dice</div><p class="mt1">${cap.nadie}</p></div>
          <div class="box paper mt1" style="border:2px dashed var(--red)"><div class="tag" style="color:var(--red)">Error de novato</div><p class="mt1">${cap.error}</p></div>
          <p class="mt2"><a class="btn sm ghost" href="libro.html#cap${cap.n}">Leer el capítulo completo</a></p>
        </div>
        <div class="tp" data-p="2" hidden>
          <p class="small mt2">Marca cada paso cuando lo termines. Tu avance se guarda.</p>
          <ul class="check mt1">${r.s.map((s, i) => `<li><label><input type="checkbox" data-s="${i}" ${st[i] ? 'checked' : ''}><span>${s}</span></label></li>`).join('')}</ul>
          <div class="progress mt1"><span id="m_bar"></span></div>
          <p class="small mt2"><b>Evidencia que entregas:</b> ${r.e}</p>
          ${r.tool ? `<a class="btn sm alt mt1" href="herramientas.html#${r.tool}">Abrir la herramienta</a>` : ''}
        </div>
        <div class="tp" data-p="3" hidden>
          <p class="mt2"><b>${q[0]}</b></p>
          <div class="opts mt1">${q[1].map((o, i) => `<button class="opt" data-o="${i}">${o}</button>`).join('')}</div>
          <p class="small mt1" id="m_fb" role="status"></p>
        </div>
        <div class="tp" data-p="4" hidden>
          <label for="m_note" class="mt2">Bitácora: ¿qué hiciste, qué descubriste y qué cambiarías?</label>
          <textarea id="m_note" rows="5" placeholder="Hoy entrevistamos a 5 personas y descubrimos que…">${esc(L.notes[id]?.txt || '')}</textarea>
          <div class="mt2" style="display:flex;gap:10px;flex-wrap:wrap"><button class="btn alt" id="m_done">${L.done[id] ? 'Misión completada ✓' : 'Completar misión'}</button><button class="btn ghost" id="m_ev">Enviar evidencia</button></div>
          <p class="small mt1" id="m_req"></p>
        </div>
      </div></div>`;
    m.hidden = false; document.body.style.overflow = 'hidden';
    const close = () => { m.hidden = true; document.body.style.overflow = ''; draw(); };
    $('.mclose', m).onclick = close; m.onclick = e => { if (e.target === m) close(); };
    document.onkeydown = e => { if (e.key === 'Escape' && !m.hidden) close(); };
    $$('.tab', m).forEach(t => t.onclick = () => { $$('.tab', m).forEach(x => x.classList.toggle('on', x === t)); $$('.tp', m).forEach(p => p.hidden = p.dataset.p !== t.dataset.t); });
    const bar = () => { $('#m_bar').style.width = Math.round(100 * st.filter(Boolean).length / st.length) + '%'; };
    $$('input[data-s]', m).forEach(c => c.onchange = () => { st[+c.dataset.s] = c.checked; L.steps[id] = st; L.save(); bar(); if (st.every(Boolean)) toast('¡Pasos listos! Ahora comprueba lo aprendido.'); });
    bar();
    let quizOk = !!L.done[id];
    $$('.opt', m).forEach(b => b.onclick = () => {
      const ok = +b.dataset.o === q[2]; b.classList.add(ok ? 'right' : 'wrong');
      $('#m_fb').textContent = (ok ? '¡Correcto! ' : 'Casi. ') + q[3]; if (ok) quizOk = true;
    });
    $('#m_note').oninput = e => { L.notes[id] = { txt: e.target.value, t: r.t, f: new Date().toISOString().slice(0, 10) }; L.save(); };
    $('#m_done').onclick = () => {
      if (L.done[id]) return;
      const miss = [];
      if (!st.every(Boolean)) miss.push('marcar todos los pasos (pestaña 2)');
      if (!quizOk) miss.push('responder bien la pregunta (pestaña 3)');
      if (($('#m_note').value || '').trim().length < 20) miss.push('escribir al menos una frase en tu bitácora');
      if (miss.length) { $('#m_req').textContent = 'Para completar te falta: ' + miss.join(', ') + '.'; return; }
      L.done[id] = new Date().toISOString().slice(0, 10); L.save(); confetti(); toast(`¡Misión completada! +${r.xp} XP · Insignia ${BADGES[r.b]}`);
      $('#m_done').textContent = 'Misión completada ✓'; $('#m_req').textContent = '';
      if (api.on() && nm.value.trim()) api.post({ type: 'progreso', nombre: nm.value.trim(), grado: gr.value.trim(), ruta: RUTAS[rt.value], xp: xpOf(), retos: Object.keys(L.done).join(', ') }).catch(() => {});
    };
    $('#m_ev').onclick = () => {
      const body = `Reto: ${r.t}\nNombre: ${nm.value}\nGrado: ${gr.value}\nBitácora: ${$('#m_note').value}\nEnlace a la evidencia: `;
      if (api.on()) { api.post({ type: 'evidencia', reto: r.t, nombre: nm.value, grado: gr.value, equipo: '', enlace: '(ver bitácora)', comentario: $('#m_note').value }).then(() => toast('Evidencia enviada')).catch(() => toast('No se pudo enviar')); }
      else location.href = `mailto:${CONFIG.email}?subject=${encodeURIComponent('Evidencia: ' + r.t)}&body=${encodeURIComponent(body)}`;
    };
  }
  $('#exportp').onclick = () => {
    const lines = RETOS.filter(r => L.done[r.id]).map(r => `• ${r.t} (${L.done[r.id]})`).join('\n');
    const notes = Object.values(L.notes).filter(n => n.txt).map(n => `— ${n.t} (${n.f}): ${n.txt}`).join('\n');
    const txt = `Pasaporte M·LAB — ${nm.value || 'Estudiante'} (${gr.value})\nRuta: ${RUTAS[rt.value]} · XP: ${xpOf()}\n\nMisiones:\n${lines || '—'}\n\nBitácora:\n${notes || '—'}`;
    navigator.clipboard?.writeText(txt).then(() => toast('Pasaporte y bitácora copiados'), () => { $('#bitacora').textContent = txt; });
  };
  $('#resetp').onclick = () => { const b = $('#resetp'); if (b.dataset.sure) { L.done = {}; L.steps = {}; L.save(); draw(); b.textContent = 'Reiniciar'; delete b.dataset.sure; } else { b.dataset.sure = 1; b.textContent = '¿Seguro? Toca otra vez'; } };
  draw();
  const h = location.hash.slice(1); if (h && RETOS.find(r => r.id === h)) openMision(h);
}

/* ---------- LIBRO ---------- */
function initLibro() {
  const lib = $('#libro'); if (!lib) return;
  const toc = $('#toc');
  toc.innerHTML = [1, 2, 3, 4].map(p => `<div class="tag mt2" style="color:var(--orange)">${String(p).padStart(2, '0')} · ${PARTES[p].name}</div>` +
    GUIA.filter(c => c.part === p).map(c => `<a href="#cap${c.n}" data-c="${c.n}" class="tocl ${L.read[c.n] ? 'leido' : ''}"><span>${String(c.n).padStart(2, '0')}</span>${c.short}</a>`).join('')).join('');
  function show(n) {
    const c = GUIA.find(x => x.n === n) || GUIA[0];
    const retos = RETOS.filter(r => capOf(r) === c.n);
    lib.innerHTML = `<div class="libimg" style="background-image:url('assets/img/${c.ill}.webp')"></div>
      <span class="kicker fill mt2">Capítulo ${c.n} · ${c.short}</span><h2 class="mt1">${c.title}</h2>
      <div class="box navy mt2"><div class="tag" style="color:var(--yellow)">En 10 segundos</div><p class="mt1">${c.tldr}</p></div>
      <div class="libbody mt2">${c.body.map(([h, t]) => `<h4>${h}</h4><p>${t}</p>`).join('')}</div>
      <div class="grid2 mt2" style="gap:14px"><div class="box yellow"><div class="tag">Lo que nadie te dice</div><p class="mt1">${c.nadie}</p></div><div class="box paper" style="border:2px dashed var(--red)"><div class="tag" style="color:var(--red)">Error de novato</div><p class="mt1">${c.error}</p></div></div>
      <div class="box lav mt2"><div class="tag">EcoNotas · parte ${c.n}</div><p class="mt1">${c.eco}</p></div>
      <div class="box orange mt2"><div class="tag" style="color:var(--navy)">Tu misión</div><p class="mt1">${c.mision}</p></div>
      ${retos.length ? `<p class="mt2"><b>Practícalo:</b> ${retos.map(r => `<a class="btn sm mt1" href="retos.html#${r.id}">${r.t}</a>`).join(' ')}</p>` : ''}
      <div class="mt3" style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap">
        ${c.n > 1 ? `<a class="btn ghost sm" href="#cap${c.n - 1}">← Anterior</a>` : '<span></span>'}
        <button class="btn sm ${L.read[c.n] ? 'ghost' : 'alt'}" id="leido">${L.read[c.n] ? 'Leído ✓' : 'Marcar como leído'}</button>
        ${c.n < 17 ? `<a class="btn sm" href="#cap${c.n + 1}">Siguiente →</a>` : '<span></span>'}</div>`;
    $('#leido').onclick = () => { L.read[c.n] = true; L.save(); show(c.n); $(`[data-c="${c.n}"]`).classList.add('leido'); updLib(); toast('Capítulo marcado como leído'); };
    $$('.tocl').forEach(a => a.classList.toggle('on', +a.dataset.c === c.n));
    lib.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  const updLib = () => { const n = Object.keys(L.read).length; $('#libprog').style.width = (100 * n / 17) + '%'; $('#libn').textContent = n; };
  const route = () => show(parseInt((location.hash.match(/cap(\d+)/) || [0, 1])[1], 10));
  addEventListener('hashchange', route); route(); updLib();
  const g = $('#glosario'); if (g) g.innerHTML = GLOSARIO.map(([a, b]) => `<details class="gl"><summary>${a}</summary><p>${b}</p></details>`).join('');
}

/* ---------- HERRAMIENTAS EXTRA ---------- */
function initTools2() {
  if (!$('#canvas')) return;
  // Lienzo M·LAB
  const cv = store.get('canvas', {});
  $$('#canvas textarea').forEach(t => { t.value = cv[t.id] || ''; t.oninput = () => { cv[t.id] = t.value; store.set('canvas', cv); }; });
  $('#cv_copy').onclick = () => navigator.clipboard?.writeText($$('#canvas textarea').map(t => `${t.dataset.l}: ${t.value}`).join('\n')).then(() => toast('Lienzo copiado'));
  // Mapa de empatía
  const em = store.get('empatia', {});
  $$('#empatia textarea').forEach(t => { t.value = em[t.id] || ''; t.oninput = () => { em[t.id] = t.value; store.set('empatia', em); }; });
  // SCAMPER
  const SC = [['Sustituye', '¿Qué material, persona o paso podrías cambiar por otro?'], ['Combina', '¿Con qué otro producto o servicio lo podrías unir?'], ['Adapta', '¿Qué idea de otro lugar (un juego, la naturaleza, otro país) puedes copiar y ajustar?'], ['Modifica', '¿Qué pasa si lo haces más grande, más pequeño, más rápido o de otro color?'], ['Otro uso', '¿Quién más podría usarlo, o para qué otra cosa sirve?'], ['Elimina', '¿Qué parte podrías quitar sin que deje de funcionar?'], ['Reordena', '¿Qué pasa si inviertes el orden de los pasos?']];
  $('#sc_go').onclick = () => { const s = SC[Math.floor(Math.random() * SC.length)]; $('#sc_out').innerHTML = `<div class="tag" style="color:var(--yellow)">${s[0]}</div><p class="deck mt1" style="color:var(--cream)">${s[1]}</p>`; };
  // Constructor de pitch
  const P = () => { const g = id => ($('#' + id).value.trim() || `[${$('#' + id).placeholder}]`);
    const txt = `${g('pi1')}. Esto le pasa a ${g('pi2')}. Nosotros creamos ${g('pi3')}. Lo probamos con ${g('pi4')} y descubrimos que ${g('pi5')}. Necesitamos ${g('pi6')} para seguir. ${g('pi7')}`;
    $('#pi_out').innerHTML = `<p style="font-size:18px;line-height:1.5">${esc(txt)}</p><p class="small muted mt1">${txt.split(/\s+/).length} palabras · ≈ ${Math.round(txt.split(/\s+/).length / 2.3)} segundos en voz alta</p>`; };
  $$('#pitchb input').forEach(i => i.oninput = P); P();
  // Flujo de caja
  const fl = $('#fl_rows');
  const addF = (sem, ing, gas) => { const tr = document.createElement('tr'); tr.innerHTML = `<td><input value="${sem}"></td><td><input type="number" value="${ing}"></td><td><input type="number" value="${gas}"></td><td class="sal"></td>`; fl.appendChild(tr); $$('input', tr).forEach(i => i.oninput = F); F(); };
  const F = () => { let s = 0, min = Infinity; $$('tr', fl).forEach(tr => { const [, i, g] = $$('input', tr).map(x => parseFloat(x.value) || 0); s += i - g; min = Math.min(min, s); const c = $('.sal', tr); c.textContent = fmt(s); c.style.color = s < 0 ? 'var(--red)' : ''; });
    $('#fl_out').innerHTML = `<div class="tag" style="color:var(--yellow)">Saldo final</div><div class="big">${fmt(s)}</div><p>${min < 0 ? `⚠️ En algún momento la caja queda en ${fmt(min)}: necesitas plata antes de vender o reducir gastos al inicio.` : 'La caja nunca queda en negativo. ¡Bien planeado!'}</p>`; };
  $('#fl_add').onclick = () => addF('Semana ' + ($$('tr', fl).length + 1), 0, 0);
  addF('Semana 1', 0, 6000); addF('Semana 2', 4000, 1500); addF('Semana 3', 6000, 1000); addF('Semana 4', 5000, 500);
  // Validación
  const VA = () => { const n = +$('#va_n').value || 0, k = +$('#va_k').value || 0, meta = +$('#va_meta').value || 0; const p = n ? Math.round(100 * k / n) : 0;
    const msg = n < 5 ? 'Prueba con al menos 5 personas antes de decidir.' : p >= meta ? 'Superaste tu meta: sigue y prueba con más personas.' : p >= meta * .6 ? 'Cerca de la meta: mejora una cosa y vuelve a probar.' : 'Lejos de la meta: revisa el problema o el público antes de seguir.';
    $('#va_out').innerHTML = `<div class="tag" style="color:var(--yellow)">Tasa de éxito</div><div class="big">${p} %</div><div class="progress mt1"><span style="width:${Math.min(100, p)}%"></span></div><p class="mt1">${msg}</p>`; };
  $$('#validacion input').forEach(i => i.oninput = VA); VA();
  // Ruleta de roles
  const ROLES = ['Líder de la semana', 'Investigación', 'Prototipo', 'Finanzas', 'Comunicación', 'Calidad y tiempo'];
  $('#ro_go').onclick = () => { const ns = $('#ro_names').value.split(/[,\n]/).map(s => s.trim()).filter(Boolean); if (ns.length < 2) { toast('Escribe al menos 2 nombres'); return; }
    const sh = ns.sort(() => Math.random() - .5); $('#ro_out').innerHTML = '<ul style="list-style:none;display:grid;gap:8px">' + sh.map((n, i) => `<li style="display:flex;justify-content:space-between;gap:10px"><b>${esc(n)}</b><span>${ROLES[i % ROLES.length]}</span></li>`).join('') + '</ul><p class="small muted mt1">Roten cada semana para que todos aprendan todo.</p>'; };
}

document.addEventListener('DOMContentLoaded', () => { initRuta(); initLibro(); initTools2(); });
